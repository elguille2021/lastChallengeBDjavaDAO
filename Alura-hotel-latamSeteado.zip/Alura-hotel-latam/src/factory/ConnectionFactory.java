/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factory;

/**
 *
 * @author Memo Serrano
 */
import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource; //esto no funciona en netbeans solo en clipse ademas el proyecto no se importó sino se desempaquetó manualmente y renombró la carpeta a alura.hotel.latam igual como se llama el paquete aquí pero y aunque ya compila las librerias a bd como estas no se importan bien por que vienen de eclipse originalmente sin embargo una solucion es importar manualmente en la carpeta del proyecto  librie una por una las librerias JAR

public class ConnectionFactory {
    public DataSource dataSource; // el import javax.sql lo pidió aquí
    //sigue el constructor ConnFactory  "siempre debe haber un constructor"
    public ConnectionFactory(){
        ComboPooledDataSource combopooled = new ComboPooledDataSource();
        combopooled.setJdbcUrl("jdbc:mysql://localhost/hotelAluraLatam?useTimezone=true&serverTimezone=UTC");
        //uso de nuevo el objeto para setar(de.set) mi usuario y contraseña
        combopooled.setUser("root");
        combopooled.setPassword("root");
        
        this.dataSource=combopooled;
    }
//lo que va dentro de jdbcUrl() hasta el signo de preguntas es el PAD PATH o ruta de la bd y del ? son configuraciones y parametros que le estamos mandando a lbd
    //Aguas con escribir mal VA UN SOLO . y NO va :  No es comboPooled.set.JdbcUrl:  sino   combopooled.setJdbcUrl(y aqui va el PAD y luego del ? parametros de zona horaria y de compatilidad de caracteres que les estamos pasandoa la bd)

// Public Connection recuperarConexion(){   //aqui daba un error ver la nota que sigue
//return this.dataSource.getConnection();  

// NOTA //cuando aqui da un error es porque necesita ser tratado con try catch
//entonces el error debe ser tratado con una excepcion,  y tenemos 2 formas de tratar esta excepción 
//una es hacer una declaracion en el copo de nuestra funcion  con "Add throws declaration"  donde ella
//se encarga de avisar de una forma que no sabemos al usuario del error 
//
//o la 2da forma que es mediante un Surround try-catch  --que es la que usamos para la excepción
//
//entonces repitiendo la ultima linea , pero adicionando el try-catch
   
    public Connection recuperarConexión(){
 try{
    return this.dataSource.getConnection();
  { catch (SQLException e) { 
     throw new RuntimeException(e);
  }
 }
    
    
    
    
//    private static class ComboPooledDataSource { //Con la libreria de .com.mchange no hacía falta que netbens tenga que crear esta clase
//
//        public ComboPooledDataSource() {
//        }
//    }        Ctrl + shift + C   Toggle  
}
